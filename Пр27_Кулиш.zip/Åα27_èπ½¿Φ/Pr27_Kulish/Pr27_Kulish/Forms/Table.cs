﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pr27_Kulish.Forms
{
    public partial class Table : Form
    {
        public string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\PK_salary.mdf;Integrated Security=True";
        public Table()
        {
            InitializeComponent();
            ToolTip tip = new ToolTip();
            tip.SetToolTip(listBoxKriteri, "Выбиерите критерий для сортировки");
            tip.SetToolTip(radioButtonDown, "Выбрать сортировку по возрастанию");
            tip.SetToolTip(radioButtonUp, "Выбрать сортировку по убыванию");
            tip.SetToolTip(buttonSort, "Применить сортировку");
            tip.SetToolTip(comboBoxFilter, "Выберите критерий для фильтрации");
        }

        private void Table_Load(object sender, EventArgs e)
        {
            string query =
                "SELECT " +
                "[Workers].[IdWorker], " +
                "[Workers].[Name], " +
                "[Workers].[Surname], " +
                "[Workers].[Age], " +
                "[Qval].[Name], " +
                "[Qval].[Oklad], " +
                "[Qval].[Descr] " +
                "FROM " +
                "[Workers], " +
                "[Qval] " +
                "WHERE " +
                "([Workers].[IdQval]=[Qval].[IdQval]) ";
                //"([Tours].[" + what + "]='" + value + "') ";
            Zapros(query);
        }
        private void Zapros(string query)
        {
            dataGridViewTableView.Rows.Clear();

            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            List<string[]> data = new List<string[]>();
            while (reader.Read())
            {
                data.Add(new string[6]);
                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
                data[data.Count - 1][2] = reader[2].ToString();
                data[data.Count - 1][3] = reader[3].ToString();
                data[data.Count - 1][4] = reader[4].ToString();
                data[data.Count - 1][5] = reader[5].ToString();
            }
            reader.Close();
            connection.Close();
            foreach (string[] s in data)
            {
                dataGridViewTableView.Rows.Add(s);
            }
            StatusLabel.Text = "Количество записей: " + (dataGridViewTableView.RowCount-1).ToString();
        }
        private System.Windows.Forms.DataGridViewColumn COL;
        private void buttonSort_Click(object sender, EventArgs e)
        {
            switch (listBoxKriteri.SelectedIndex)
            {
                case 0:
                    COL = ColumnName;
                    break;
                case 1:
                    COL = ColumnAge;
                    break;
                case 2:
                    COL = ColumnQval;
                    break;
            }
            if (radioButtonDown.Checked)
                dataGridViewTableView.Sort(COL, System.ComponentModel.ListSortDirection.Ascending);
            else dataGridViewTableView.Sort(COL, System.ComponentModel.ListSortDirection.Descending);
        }

        private void listBoxKriteri_SelectedIndexChanged(object sender, EventArgs e)
        {
            buttonSort.Enabled = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBoxFilter.SelectedIndex)
            {
                case 0:
                    Table_Load(sender, e);
                    break;
                case 1:
                    FindBy("1");
                    break;
                case 2:
                    FindBy("2"); 
                    break;
                case 3:
                    FindBy("3");
                    break;
            }
        }
        private void FindBy(string value)
        {
            string query =
                "SELECT " +
                "[Workers].[IdWorker], " +
                "[Workers].[Name], " +
                "[Workers].[Surname], " +
                "[Workers].[Age], " +
                "[Qval].[Name], " +
                "[Qval].[Oklad], " +
                "[Qval].[Descr] " +
                "FROM " +
                "[Workers], " +
                "[Qval] " +
                "WHERE " +
                "([Workers].[IdQval]=[Qval].[IdQval]) AND " +
                "([Workers].[IdQval]="+value+") ";
            Zapros(query);
        }

        public void toolStripButtonExport_Click(object sender, EventArgs e)
        {
            var xlApp = new Microsoft.Office.Interop.Excel.Application();
            xlApp.Visible = true;

            //Книга
            Microsoft.Office.Interop.Excel.Workbook wBook;
            Microsoft.Office.Interop.Excel.Worksheet xlSheet;
            wBook = xlApp.Workbooks.Add();
            xlApp.Columns.ColumnWidth = 30;

            //Лист
            xlSheet = (Microsoft.Office.Interop.Excel.Worksheet)wBook.Sheets[1];
            //Присвоепние имени листа
            xlSheet.Name = "Зарплата";

            //Наименование ккаждого столбца
            xlSheet.Cells[1, 1] = "ID";
            xlSheet.Cells[1, 2] = "Имя";
            xlSheet.Cells[1, 3] = "Фамилия";
            xlSheet.Cells[1, 4] = "Возраст";
            xlSheet.Cells[1, 5] = "Квалификация";
            xlSheet.Cells[1, 6] = "Оклад";

            for (int i = 0; i < dataGridViewTableView.Rows.Count - 1; i++)
            {
                for (int j = 0; j < dataGridViewTableView.Columns.Count; j++)
                {
                    xlApp.Cells[i + 2, j + 1] = dataGridViewTableView.Rows[i].Cells[j].Value.ToString();
                }
            }
            xlSheet.Cells.HorizontalAlignment = 3;
            xlApp.Visible = true;
        }

        private void toolStripButtonAdd_Click(object sender, EventArgs e)
        {
            AddNewWorker form = new AddNewWorker();
            form.Owner = this;
            form.Show();
        }

        private void toolStripButtonDelete_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand command = new SqlCommand("DELETE FROM [Workers] WHERE IdWorker = @pId", connection); //TableName - имя таблицы, из которой удаляете запись
            command.Parameters.Add(new SqlParameter("@pId", this.dataGridViewTableView.CurrentRow.Cells["ColumnId"].Value)); //DataGridViewName - имя DataGridView на форме
            command.ExecuteNonQuery();
            connection.Close();
            Table_Load(sender, e);
        }
    }
}
