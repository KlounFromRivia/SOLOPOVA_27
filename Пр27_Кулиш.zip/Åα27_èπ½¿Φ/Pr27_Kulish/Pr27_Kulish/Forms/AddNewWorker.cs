﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Pr27_Kulish.Forms
{
    public partial class AddNewWorker : Form
    {
        public AddNewWorker()
        {
            InitializeComponent();
        }

        private void AddNewWorker_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pK_salaryDataSet.Qval". При необходимости она может быть перемещена или удалена.
            this.qvalTableAdapter.Fill(this.pK_salaryDataSet.Qval);
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            WorkersTable main = this.Owner as WorkersTable;
            if (main != null)
            {
                DataRow nRow = main.pK_salaryDataSet.Tables[1].NewRow();
                nRow[0] = numericUpDownID.Value;
                nRow[1] = textBoxName.Text;
                nRow[2] = textBoxSurname.Text;
                nRow[3] = comboBoxQval.SelectedValue;
                nRow[4] = numericUpDownAge.Value;

                main.pK_salaryDataSet.Tables[1].Rows.Add(nRow);
                main.workersTableAdapter.Update(main.pK_salaryDataSet.Workers);
                main.pK_salaryDataSet.Tables[1].AcceptChanges();
                main.WorkersTable_Load(sender, e);

                this.numericUpDownID.Value = 0;
                this.textBoxName.Text = "";
                this.textBoxSurname.Text = "";
                this.numericUpDownAge.Value = 0;
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBoxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) && e.KeyChar != Convert.ToChar(8))
            {
                e.Handled = true;
            }
        }
    }
}
