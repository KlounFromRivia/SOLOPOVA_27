﻿using Pr27_Kulish.Forms;
using System;
using System.Windows.Forms;

namespace Pr27_Kulish
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void сотрудникиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WorkersTable form = new WorkersTable();
            form.Owner = this;
            form.Show();
        }

        private void табличнаяФормаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Table form = new Table();
            form.Owner = this;
            form.Show();
        }

        private void добавитьСотрудникаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WorkersTable form = new WorkersTable();
            form.Owner = this;
            form.Show();
            form.toolStripButtonAdd_Click(sender, e);
        }

        private void выходныеДокументыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Table form = new Table();
            form.Owner = this;
            form.Show();
            form.toolStripButtonExport_Click(sender, e);
            form.Close();
        }

        private void вызовСправкиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, helpProvider1.HelpNamespace);
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox aboutProgrammForm = new AboutBox();
            aboutProgrammForm.ShowDialog();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
