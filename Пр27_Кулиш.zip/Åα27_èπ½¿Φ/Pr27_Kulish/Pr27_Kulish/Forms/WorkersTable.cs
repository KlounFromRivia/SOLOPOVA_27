﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pr27_Kulish.Forms
{
    public partial class WorkersTable : Form
    {
        public string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\PK_salary.mdf;Integrated Security=True";
        public WorkersTable()
        {
            InitializeComponent();
        }

        public void WorkersTable_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pK_salaryDataSet.Workers". При необходимости она может быть перемещена или удалена.
            this.workersTableAdapter.Fill(this.pK_salaryDataSet.Workers);
            string query =
                "SELECT * " +
                "FROM " +
                "[Workers] ";
            Zapros(query);
            StatusLabel.Text = "Количество записей: " + (dataGridViewWorkers.RowCount - 1).ToString();
        }

        private void Zapros(string query)
        {
            dataGridViewWorkers.Rows.Clear();

            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            List<string[]> data = new List<string[]>();
            while (reader.Read())
            {
                data.Add(new string[5]);
                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
                data[data.Count - 1][2] = reader[2].ToString();
                data[data.Count - 1][3] = reader[3].ToString();
                data[data.Count - 1][4] = reader[4].ToString();
            }
            reader.Close();
            connection.Close();
            foreach (string[] s in data)
            {
                dataGridViewWorkers.Rows.Add(s);
            }
            //Status();
        }
        public void toolStripButtonAdd_Click(object sender, EventArgs e)
        {
            AddNewWorker form = new AddNewWorker();
            form.Owner = this;
            form.Show();
        }

        private void toolStripButtonDelete_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand command = new SqlCommand("DELETE FROM [Workers] WHERE IdWorker = @pId", connection); //TableName - имя таблицы, из которой удаляете запись
            command.Parameters.Add(new SqlParameter("@pId", this.dataGridViewWorkers.CurrentRow.Cells["ColumnId"].Value)); //DataGridViewName - имя DataGridView на форме
            command.ExecuteNonQuery();
            connection.Close();
            WorkersTable_Load(sender, e);
        }
    }
}
